from django.shortcuts import render
from .models import Oprendszer, Processzor, Gep
#from .models import Gep

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseForbidden, HttpResponseNotFound, HttpResponseServerError, HttpResponseBadRequest

def index(request):
    return render(request, '10okt/index.html')

def feltolt_urlap(request):
    template = 'feltolt.html'
    context = {}
    return render(request, template, context)
#"""
def feltolt_oprendszer(request):
    
    darab, error = Oprendszer.feltolt(request.POST['inputcsv'])

    return HttpResponse(f'Sikerült!! {darab} db új elem jött létre az adatbázisban, így most összesen {Oprendszer.objects.all().count()} db rekord van az adatbázisban.')

def feltolt_processzor(request):
    
    darab, error = Processzor.feltolt(request.POST['inputcsv'])

    return HttpResponse(f'Sikerült!! {darab} db új elem jött létre az adatbázisban, így most összesen {Processzor.objects.all().count()} db rekord van az adatbázisban.')
#"""
def feltolt_gep(request):
    
    darab, error = Gep.feltolt(request.POST['inputcsv'])

    return HttpResponse(f'Sikerült!! {darab} db új elem jött létre az adatbázisban, így most összesen {Gep.objects.all().count()} db rekord van az adatbázisban.')

def feladat_2_kerdes(request):
    template = '10okt/feladat_2_kerdes.html'
    ettol = 0
    eddig = 500
    context = {
        'ettol': ettol,
        'eddig': eddig,
    }

    return render(request, template, context)

def feladat_2_valasz(request):
    if request.method!='POST':
        return redirect('/2010/okt/')
    
    try:
        szam = int(request.POST['szam'])
    except: 
        return HttpResponseBadRequest('az év nem szám.')
    
    # -------------------------------------------------------

    gepek = [gep for gep in Gep.objects.all() if gep.merevlemez >= szam and gep.db >=1]
    
    template = '10okt/feladat_2_valasz.html'
    context = {
        'szam': szam,
        'gepek': gepek,
    }
    return render(request, template, context)

def feladat3(request):
    sorok = sorted(Gep.melyik_gyarto_mennyi(), key=lambda sor: sor['gyarto'])
    
    template = '10okt/feladat3.html'
    context = {
        'sorok': sorok,
    }
    
    return render(request, template, context)

def feladat4(request):
    osszeg = 0
    for gep in Gep.objects.all(): 
        osszeg = (gep.ar * gep.db) + osszeg
    
    template = '10okt/feladat4.html'
    context = {
        'osszeg': osszeg,
    }
    
    return render(request, template, context)