from django.contrib import admin

# Register your models here.
from .models import Oprendszer, Processzor,Gep
#from .models import Gep

admin.site.register(Oprendszer)
admin.site.register(Processzor)
admin.site.register(Gep)

