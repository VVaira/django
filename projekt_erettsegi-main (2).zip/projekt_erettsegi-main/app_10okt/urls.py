from django.urls import path
#from .views import index, feltolt_urlap, feltolt_gep, feladat_2_kerdes, feladat_2_valasz, feladat3, feladat4
from .views import index, feltolt_urlap, feltolt_oprendszer, feltolt_processzor, feltolt_gep, feladat_2_kerdes, feladat_2_valasz, feladat3, feladat4
#from .views import feltolt_get, feltolt_post, index, feladat_2_kerdes, feladat_3_kerdes, feladat_4_kerdes, feladat_2_valasz, feladat_3_valasz, feladat_4_valasz, feladat_5_valasz, feladat_6_valasz

# most külön view-t kap a get és a post request.
# a tábla nevét így lehet elegánsan változóként kivenni az url-ből. 

urlpatterns = [
    path('', index),
    path('feltolt/oprendszer/',feltolt_urlap),
    path('feltolt/processzor/',feltolt_urlap),
    path('feltolt/gep/',feltolt_urlap),
    path('feladat/2/', feladat_2_kerdes),
    path('feladat/3/', feladat3),
    path('feladat/4/', feladat4),   
    path('feltolt/oprendszer/post/',feltolt_oprendszer),
    path('feltolt/processzor/post/',feltolt_processzor),
    #path('feltolt/oprendszer/post/',feltolt_gep),
    #path('feltolt/processzor/post/',feltolt_gep),
    path('feltolt/gep/post/',feltolt_gep),
    path('feladat/2/post/', feladat_2_valasz),
]