from django.contrib import admin

from .models import Kerulet, Varosresz

admin.site.register(Kerulet)
admin.site.register(Varosresz)