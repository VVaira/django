from django.db import models

# Create your models here.
class Oprendszer(models.Model):
    opid = models.IntegerField()
    nev = models.CharField(max_length = 255)
    
    
    class Meta:
        verbose_name = "Oprendszer"
        verbose_name_plural = "Oprendszerek"
        
    def __str__(self): 
        return f'{self.opid}, {self.nev}'
    
    def feltolt(inputcsv):
        sorok = [ sor.strip() for sor in inputcsv.strip().split('\n')]
        darab = 0

        for i, sor in enumerate(sorok[1:]):
            sortomb = sor.split('\t')
        

            _, is_created = Oprendszer.objects.get_or_create(
                opid = int(sortomb[0]),
                nev = sortomb[1],
            )

            if  is_created:
                darab += 1

        return (darab, None)


class Processzor(models.Model):
    proid = models.IntegerField()
    gyarto = models.CharField(max_length = 255)
    tipus = models.CharField(max_length = 255)
    
    class Meta:
        verbose_name = "Processzor"
        verbose_name_plural = "Processzorok"
        
    def __str__(self): 
        return f'{self.proid}, {self.gyarto}, {self.tipus}'
    
    def feltolt(inputcsv):
        sorok = [ sor.strip() for sor in inputcsv.strip().split('\n')]
        darab = 0

        for i, sor in enumerate(sorok[1:]):
            sortomb = sor.split('\t')
        

            _, is_created = Processzor.objects.get_or_create(
                proid = int(sortomb[0]),
                gyarto = sortomb[1],
                tipus = sortomb[2],
            )

            if  is_created:
                darab += 1

        return (darab, None)
#"""
class Gep(models.Model):
    gyarto = models.CharField(max_length = 255)
    tipus = models.CharField(max_length = 255)
    kijelzo = models.IntegerField()
    memoria = models.IntegerField()
    merevlemez = models.IntegerField()
    videovezerlo = models.CharField(max_length=255)
    ar = models.IntegerField()
    oprendszer = models.ForeignKey(Oprendszer, on_delete=models.CASCADE)
    processzor = models.ForeignKey(Processzor, on_delete=models.CASCADE)
    db = models.IntegerField()
    
    class Meta:
        verbose_name = "Gép"
        verbose_name_plural = "Gépek"
        
    def __str__(self): 
        return f'{self.gyarto}, {self.tipus}, {self.kijelzo}, {self.memoria}, {self.merevlemez}, {self.videovezerlo}, {self.ar}, {self.processzor}, {self.oprendszer}, {self.db}'
    
    def feltolt(inputcsv):
       
        sorok = [ sor.strip() for sor in inputcsv.strip().split('\n')]
        darab = 0

        for i, sor in enumerate(sorok[1:]):
            sortomb = sor.split('\t')
            
            try:
                a_kijelzo = float(sortomb[2].replace(',','.'))
            except:
                return (darab, f'a(z) {i+1}. rekordban a harmadik mezőben nem tizedestört található!')

            oprendszer = int(sortomb[8]) 
            a_oprendszer = Oprendszer.objects.filter(opid=oprendszer).first() 

            processzor = int(sortomb[7]) 
            a_processzor = Processzor.objects.filter(proid=processzor).first()          
                    
            _, is_created = Gep.objects.get_or_create(
                gyarto = sortomb[0],
                tipus = sortomb[1],
                kijelzo = a_kijelzo,
                memoria = sortomb[3],
                merevlemez = sortomb[4],
                videovezerlo = sortomb[5],
                ar = sortomb[6],
                oprendszer = a_oprendszer,
                processzor = a_processzor,
                #oprendszer = 1,
                #processzor = 1,
                db = sortomb[9],
                
            )

            if  is_created:
                darab += 1

        return (darab, None)
    #"""
    def melyik_gyarto_mennyi():
        szotar = {}
        for gep in Gep.objects.all():
            if gep.gyarto in szotar.keys():
                szotar[gep.gyarto] += 1
            else:
                szotar[gep.gyarto] = 1
        
        return [{'gyarto': gyarto, 'db': szotar[gyarto]} for gyarto in szotar.keys()] 