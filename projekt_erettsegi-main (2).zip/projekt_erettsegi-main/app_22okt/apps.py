from django.apps import AppConfig


class App22OktConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_22okt'
